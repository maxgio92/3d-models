Ashtray Replacement for BMW F10 by Jctree25 on Thingiverse: https://www.thingiverse.com/thing:4542056

Summary:
Replaces metal ashtray in 5 series BMW with a more useful box.